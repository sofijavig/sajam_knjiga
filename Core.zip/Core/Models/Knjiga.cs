﻿using System;
using System.Collections.Generic;

namespace Core.Models
{
    public class Knjiga
    {
        public string ISBN { get; set; } = string.Empty;
        public string Naziv { get; set; } = string.Empty ;
        public string Zanr { get; set; } = string.Empty;
        public int GodinaIzdanja { get; set; }
        public int Cena { get; set; }
        public int BrojStrana { get; set; }
        public List<Autor> Autori { get; set; } = [];
        public string Izdavac { get; set; } = string.Empty;
        public List<Posetilac> Lista_Kupaca { get; set; } = [];
        public List<Posetilac> Lista_Zelja { get; set; } = [];

        public override string ToString()
        {
            return $"{Naziv} ({ISBN}) — {Izdavac} — {Zanr} — {GodinaIzdanja} — {Cena} RSD — {BrojStrana} str.";
        }

        public void Validate()
        {
            if (string.IsNullOrWhiteSpace(ISBN))
                throw new ArgumentException("ISBN mora postojati.", nameof(ISBN));

            if (ISBN.Length != 6)
                throw new ArgumentException("ISBN mora biti 6 karaktera.");

            if (string.IsNullOrWhiteSpace(Naziv))
                throw new ArgumentException("Naziv neophodan.", nameof(Naziv));

            if (string.IsNullOrWhiteSpace(Izdavac))
                throw new ArgumentException("Izdavac neophodan.", nameof(Izdavac));

            if (Cena <= 0)
                throw new ArgumentException("Cena mora biti veća od 0.");

            if (BrojStrana <= 0)
                throw new ArgumentException("Broj strana mora biti veći od 0.");
        }
    }
}
