﻿using Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DAO
{
    public class KupovinaDAO
    {
        private const string KupovinaFajl = "kupovine.txt";
        public List<Kupovina> Ucitaj()
        {
            List<Kupovina> kupovine = new List<Kupovina>();
            if (!File.Exists(KupovinaFajl))
                return kupovine;
            string[] linije = File.ReadAllLines(KupovinaFajl);
            for (int i = 0; i < linije.Length; i++)
            {
                if (string.IsNullOrEmpty(linije[i]))
                    continue;
                string[] delovi = linije[i].Split('|');
                Kupovina kup = new Kupovina();
                kup.Pos = new Posetilac();
                kup.Pos.CK = delovi[0];
                kup.Knj = new Knjiga();
                kup.Knj.ISBN = delovi[1];
                kup.DatKup = DateTime.Parse(delovi[2]);
                kup.Ocena = int.Parse(delovi[3]);
                kup.Komentar = delovi[4];
                kup.Validacija();
                kupovine.Add(kup);
            }
            return kupovine;
        }
        public void Sacuvaj(List<Kupovina> kupovine)
        {
            List<string> linije = new List<string>();
            for (int i = 0; i < kupovine.Count; i++)
            {
                Kupovina kup = kupovine[i];
                string tekst = kup.Pos.CK + '|' + kup.Knj.ISBN + '|' + kup.DatKup.ToString("yyyy-MM-dd") + '|' + kup.Ocena + '|' + kup.Komentar;
                linije.Add(tekst);
            }
            File.WriteAllLines(KupovinaFajl, linije);
        }
    }
}
