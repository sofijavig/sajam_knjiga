﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Core.Models;

namespace Core.DAO
{
    public class KnjigaDAO
    {
        private readonly string fajl_knjige = "knjige.txt";

        public void Add(Knjiga knjiga)
        {
            var list = Load();
            list.Add(knjiga);
            Save(list);
        }

        public List<Knjiga> Load()
        {
            var list = new List<Knjiga>();
            if (!File.Exists(fajl_knjige))
                return list;

            foreach (var line in File.ReadAllLines(fajl_knjige))
            {
                var s = line.Split('|'); // Format: ISBN|Naziv|Zanr|GodinaIzdanja|Cena|BrojStrana|Izdavac
                list.Add(new Knjiga
                {
                    ISBN = s[0],
                    Naziv = s[1],
                    Zanr = s[2],
                    GodinaIzdanja = int.Parse(s[3]),
                    Cena = int.Parse(s[4]),
                    BrojStrana = int.Parse(s[5]),
                    Izdavac = s[6]
                });
            }

            return list;
        }

        public void Save(List<Knjiga> knjige)
        {
            var lines = new List<string>();
            foreach (var k in knjige)
                lines.Add($"{k.ISBN}|{k.Naziv}|{k.Zanr}|{k.GodinaIzdanja}|{k.Cena}|{k.BrojStrana}|{k.Izdavac}");

            File.WriteAllLines(fajl_knjige, lines);
        }

        // Metoda za pronalaženje knjige po ISBN-u
        public Knjiga? GetByISBN(string isbn)
        {
            return Load().FirstOrDefault(k => k.ISBN == isbn);
        }
    }
}