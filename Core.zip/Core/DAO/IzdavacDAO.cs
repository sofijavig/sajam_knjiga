﻿using Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DAO
{
    public class IzdavacDAO
    {

        private const string IzdavacFajl = "izdavaci.txt";
        public List<Izdavac> Ucitaj()
        {
            List<Izdavac> izdavaci = new List<Izdavac>();
            if (!File.Exists(IzdavacFajl))
                return izdavaci;
            string[] linije = File.ReadAllLines(IzdavacFajl);
            for (int i = 0; i < linije.Length; i++)
            {
                if (string.IsNullOrEmpty(linije[i]))
                    continue;
                string[] delovi = linije[i].Split('|');
                Izdavac izd = new Izdavac();
                izd.Sifra=delovi[0];
                izd.Naziv=delovi[1];
                izd.Sef = new Autor();
                izd.Sef.Ime=delovi[2];
                izd.Sef.Prezime=delovi[3];
                izd.Sef.LK=delovi[4];
                izd.Sef.God_Iskustva=int.Parse(delovi[5]);
                izd.SpisakAutora = new List<Autor>();
                string[] autori = delovi[6].Split(',');
                for (int j = 0; j < autori.Length; j++)
                {
                    if (string.IsNullOrWhiteSpace(autori[j]))
                        continue;
                    Autor a = new Autor();
                    a.LK = autori[j];
                    izd.SpisakAutora.Add(a);
                }
                izd.SpisakKnjiga = new List<Knjiga>();
                string[] knjige = delovi[7].Split(',');
                for (int m = 0; m < knjige.Length; m++)
                {
                    if (string.IsNullOrWhiteSpace(autori[m]))
                        continue;
                    Knjiga k = new Knjiga();
                    k.ISBN = knjige[m];
                    izd.SpisakKnjiga.Add(k);
                }
                izd.Validacija();
                izdavaci.Add(izd);
            }
            return izdavaci;
        }
        public void Sacuvaj(List<Izdavac> izdavaci)
        {
            List<string> linije = new List<string>();
            for (int i = 0; i < izdavaci.Count; i++)
            {
                Izdavac izd = izdavaci[i];
                string autori = "";
                for (int j = 0; j < izd.SpisakAutora.Count; j++)
                {
                    if (j > 0)
                        autori=autori+ ",";
                    autori=autori+ izd.SpisakAutora[j].LK;
                }
                string knjige = "";
                for (int j = 0; j < izd.SpisakKnjiga.Count; j++)
                {
                    if (j > 0)
                        knjige= knjige + ",";
                    knjige = knjige + izd.SpisakKnjiga[j].ISBN;
                }
                string tekst = izd.Sifra+ '|' + izd.Naziv + '|' + izd.Sef.Ime + '|' + izd.Sef.Prezime + '|' + izd.Sef.LK+'|'+izd.Sef.God_Iskustva+'|'+ autori + '|' +knjige;
                linije.Add(tekst);
            }
            File.WriteAllLines(IzdavacFajl, linije);
        }
    }
}

