﻿using Core.Models;

namespace Core.DAO
{
    public class AutorDAO
    {
        private readonly string fajl_autor = "autori.txt";
        private readonly AdreseDAO adresaDAO = new();
        private readonly KnjigaDAO knjigaDAO = new();

        public void Add(Autor autor)
        {
            autor.Validate();
            var list = Load(); ///(autor) sta je load?
            list.Add(autor);
            Save(list);

            adresaDAO.Add(autor.Ad);
            foreach (var knjiga in autor.Knjige)
            {
                knjigaDAO.Add(knjiga);
            }
        }
        public List<Autor> Load()
        {
            List<Autor> autori = [];
            if (!File.Exists(fajl_autor))
            {
                return autori;
            }
            foreach (var line in File.ReadAllLines(fajl_autor))
            {
                var s = line.Split('|');
                var autor = new Autor
                {
                    LK = s[0],
                    Ime = s[1],
                    Prezime = s[2],
                    DatRodj = DateTime.Parse(s[3]),
                    BrojTelefona = s[4],
                    Mail = s[5],
                    God_Iskustva = int.Parse(s[6]),
                    Ad = new Adresa
                    {
                        Ulica = s[7],
                        Broj = int.Parse(s[8]),
                        Grad = s[9],
                        Drzava = s[10]
                    }

                };
                if (s.Length > 11 && !string.IsNullOrEmpty(s[11]))
                {
                    var ListaTokena = s[11].Split('|');
                    foreach (var token in ListaTokena)
                    {
                        var deo = token.Split(':');
                        string isbn = deo[0];

                        var knjiga = knjigaDAO.GetByISBN(isbn);
                        if (knjiga != null)
                        {
                            autor.Knjige.Add(knjiga);
                        }
                    }
                }
                autori.Add(autor);
            }
            return autori;
        }
        public void Save(List<Autor> autori)
        {
            List<string> lines = [];
            foreach(var a in autori)
            {
                string knjigeTxt = string.Join("|", a.Knjige.Select(k => $"{k.ISBN}:{k.Naziv}"));

                string line = $"{a.LK}|{a.Ime}|{a.Prezime}|{a.DatRodj}|{a.BrojTelefona}|{a.Mail}|{a.God_Iskustva}|{a.Ad.Ulica}|{a.Ad.Broj}|{a.Ad.Grad}|{a.Ad.Drzava}|{knjigeTxt}";

                lines.Add(line);

            }
            File.WriteAllLines(fajl_autor,lines);
        }
    }
}
