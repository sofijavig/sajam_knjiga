﻿using System;
using System.Collections.Generic;
using System.Linq;
using Core.Models;
using Core.DAO;

namespace Core.Services
{
    public class AutorService
    {
        private readonly AutorDAO autorDAO = new AutorDAO(); //pravi se dao objekat

        public bool AutorPostoji(string lk) //provrava da li postoji autor
        {
            var autori = autorDAO.Load(); //lista svih autora
            return autori.Any(a => a.LK == lk); //da li bilo koji medju njima ima taj lk
        }

        public void AddAutor(Autor autor)
        {
            if (AutorPostoji(autor.LK))
                throw new Exception("Autor sa ovom licnom kartom vec postoji!"); //ako je true  i postoji izbaci gresku
            autor.Validate();
            autorDAO.Add(autor); // čuva odmah u fajlu
        }

        public List<Autor> GetAll()
        {
            return autorDAO.Load();//sve autore
        }

        public Autor? GetByLK(string lk)
        {
            return autorDAO.Load().FirstOrDefault(a => a.LK == lk); //u autorima po odredjenom kljucu trazi autora
        }
        public bool UpdateAutor(string lk, Autor noviAutor) //apdejtuj odredjenog autora
        {
            var autori = autorDAO.Load();
            var autor = autori.FirstOrDefault(a => a.LK == lk); //var znaci da ce samo prepoznati kog tipa je promenljiva
            if (autor == null)
                return false;

            noviAutor.Validate();

            autor.Ime = noviAutor.Ime;
            autor.Prezime = noviAutor.Prezime;
            autor.DatRodj = noviAutor.DatRodj;
            autor.Ad = noviAutor.Ad;
            autor.BrojTelefona = noviAutor.BrojTelefona;
            autor.Mail = noviAutor.Mail;
            autor.LK = noviAutor.LK;
            autor.God_Iskustva = noviAutor.God_Iskustva; //ispisuje podatke novog autora starom
            foreach (var knjiga in noviAutor.Knjige)
            {
                if (!autor.Knjige.Any(k => k.ISBN == knjiga.ISBN))
                {
                    autor.Knjige.Add(knjiga); //da se ne bi dodale ist knjige samo razlicit
                }
            }

            autorDAO.Save(autori); // čuvanje promena u fajlu
            return true;
        }

        public bool DeleteAutor(string lk) //brisanje po kljucu
        {
            var autori = autorDAO.Load();
            var autor = autori.FirstOrDefault(a => a.LK == lk);
            if (autor == null)
                return false;

            autori.Remove(autor);
            autorDAO.Save(autori); // čuvanje promena
            return true;
        }
    }
}
