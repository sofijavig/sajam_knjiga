﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Models;
using Core.DAO;

namespace Core.Services
{
    public class PosetilacServices
    {
        private PosetilacDAO dao=new PosetilacDAO();
        public void Dodaj(Posetilac posetilac)
        {
            posetilac.Validacija();
            List<Posetilac> posetioci = dao.Ucitaj();
            for (int i = 0; i < posetioci.Count; i++)
            {
                if (posetioci[i].CK == posetilac.CK)
                    throw new ArgumentException("Posetilac sa tim CK već postoji.");
            }
            posetioci.Add(posetilac);
            dao.Sacuvaj(posetioci);
        }

        public void Izmeni(string ckIzmeni, Posetilac izmenjen) 
        {
            List<Posetilac> posetioci= dao.Ucitaj();
            bool zamenjeno= false;
            for (int i = 0; i < posetioci.Count; i++)
            {
                if (posetioci[i].CK==ckIzmeni)
                {
                    izmenjen.Validacija();
                    posetioci[i] = izmenjen;
                    zamenjeno = true;
                }
            }
            if (zamenjeno == false)
                throw new ArgumentException("Ne postoji posetilac sa ovim brojem CK");
            dao.Sacuvaj(posetioci);
        }

        public void Obrisi(string ckObrisi)
        {
            List<Posetilac> posetioci= dao.Ucitaj();
            bool obrisan= false;
            for (int i = 0; i < posetioci.Count; i++)
            {
                if (posetioci[i].CK == ckObrisi)
                {
                    posetioci.RemoveAt(i);
                    obrisan = true;
                }
            }
            if (obrisan == false)
                throw new ArgumentException("Ne postoji posetilac sa ovim brojem CK");
            dao.Sacuvaj(posetioci);
        }

        public List<Posetilac> VratiSve()
        {
            return dao.Ucitaj();
        }

        public void Prikazi()
        {
            List<Posetilac> posetioci = dao.Ucitaj();
            if (posetioci.Count == 0)
            {
                Console.WriteLine("Nema posetilaca");
                return;
            }
            for (int i = 0; i < posetioci.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + posetioci[i].ToString());
                Console.WriteLine("--------------------------------------");
            }
        }
    }
}
