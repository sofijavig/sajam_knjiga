﻿using System;
using System.Collections.Generic;
using System.Linq;
using Core.Models;
using Core.DAO;

namespace Core.Services
{
    public class KnjigaService
    {
        private readonly KnjigaDAO knjigaDAO = new KnjigaDAO();

        public bool KnjigaPostoji(string ISBN) //opet provera jl postoji knjiga vec
        {
            var knjiga = knjigaDAO.Load();
            return knjiga.Any(k => k.ISBN == ISBN);
        }

        public void AddKnjiga(Knjiga knjiga)
        {
            if(KnjigaPostoji(knjiga.ISBN))
                throw new Exception("Knjiga sa ovim ISBN vec postoji!");
            knjiga.Validate();
            knjigaDAO.Add(knjiga); // dodaje u fajl
        }

        // Dobijanje svih knjiga
        public List<Knjiga> GetAll()
        {
            return knjigaDAO.Load();
        }

        // Dobijanje knjige po ISBN
        public Knjiga? GetByISBN(string isbn)
        {
            return knjigaDAO.GetByISBN(isbn);
        }

        // Update knjige
        public bool UpdateKnjiga(string isbn, Knjiga novaKnjiga)
        {
            var knjige = knjigaDAO.Load();
            var knjiga = GetByISBN(isbn);
            if (knjiga == null)
                return false;

            novaKnjiga.Validate();

            knjiga.Naziv = novaKnjiga.Naziv;
            knjiga.Zanr = novaKnjiga.Zanr;
            knjiga.GodinaIzdanja = novaKnjiga.GodinaIzdanja;
            knjiga.Cena = novaKnjiga.Cena;
            knjiga.BrojStrana = novaKnjiga.BrojStrana;
            knjiga.Izdavac = novaKnjiga.Izdavac;

            knjigaDAO.Save(knjige); // cuvanje promena
            return true;
        }

        // Brisanje knjige
        public bool DeleteKnjiga(string isbn)
        {
            var knjige = knjigaDAO.Load();
            var knjiga = knjige.FirstOrDefault(k => k.ISBN == isbn);
            if (knjiga == null)
                return false;

            knjige.Remove(knjiga);
            knjigaDAO.Save(knjige);
            return true;
        }
    }
}
