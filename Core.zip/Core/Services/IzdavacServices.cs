﻿using Core.DAO;
using Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public class IzdavacServices
    {
        private IzdavacDAO dao = new IzdavacDAO();
        public void Dodaj(Izdavac izdavac)
        {
            AutorDAO autDao = new AutorDAO();
            List<Autor> autori = autDao.Load();
            Autor a = null;
            for (int i = 0; i < autori.Count; i++)
            {
                if (autori[i].LK == izdavac.Sef.LK)
                {
                    a = autori[i];
                    break;
                }
            }
            if (a == null)
                throw new ArgumentException("Ne postoji autor sa unetom LK.");
            a.Validate();
            izdavac.Validacija();
            List<Izdavac> izdavaci = dao.Ucitaj();
            for (int i = 0; i < izdavaci.Count; i++)
            {
                if (izdavaci[i].Sifra==izdavac.Sifra)
                    throw new ArgumentException("Izdavac sa ovom sifrom već postoji.");
            }
            izdavaci.Add(izdavac);
            dao.Sacuvaj(izdavaci);
        }

        public void Izmeni(string sifraIzmeni, Izdavac izmenjen)
        {
            List<Izdavac> izdavaci = dao.Ucitaj();
            bool zamenjeno = false;
            for (int i = 0; i < izdavaci.Count; i++)
            {
                if (izdavaci[i].Sifra==sifraIzmeni)
                {
                    izmenjen.Validacija();
                    izdavaci[i] = izmenjen;
                    zamenjeno = true;
                }
            }
            if (zamenjeno == false)
                throw new ArgumentException("Ne postoji izdavac sa ovom sifrom");
            dao.Sacuvaj(izdavaci);
        }

        public void Obrisi(string sifraObrisi)
        {
            List<Izdavac> izdavaci = dao.Ucitaj();
            bool obrisan = false;
            for (int i = 0; i < izdavaci.Count; i++)
            {
                if (izdavaci[i].Sifra == sifraObrisi)
                {
                    izdavaci.RemoveAt(i);
                    obrisan = true;
                }
            }
            if (obrisan == false)
                throw new ArgumentException("Ne postoji izdavac sa ovom sifrom");
            dao.Sacuvaj(izdavaci);
        }

        public List<Izdavac> VratiSve()
        {
            return dao.Ucitaj();
        }

        public void Prikazi()
        {
            List<Izdavac> izdavaci = dao.Ucitaj();
            if (izdavaci.Count == 0)
            {
                Console.WriteLine("Nema izdavaca");
                return;
            }
            for (int i = 0; i < izdavaci.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + izdavaci[i].ToString());
                Console.WriteLine("--------------------------------------");
            }
        }
    }
}
