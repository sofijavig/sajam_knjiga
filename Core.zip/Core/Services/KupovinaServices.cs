﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DAO;
using Core.Models;

namespace Core.Services
{
    public class KupovinaServices
    {
        private KupovinaDAO dao=new KupovinaDAO();
        public void Dodaj(Kupovina kupovina)
        {
            PosetilacDAO posDao = new PosetilacDAO();
            List<Posetilac> posetioci = posDao.Ucitaj();
            Posetilac p = null;
            for (int i = 0; i < posetioci.Count; i++)
            {
                if (posetioci[i].CK == kupovina.Pos.CK)
                {
                    p = posetioci[i];
                    break;
                }
            }    
            if (p == null)
                throw new ArgumentException("Ne postoji posetilac sa unetim CK.");
            p.Validacija();
            KnjigaDAO knjDao = new KnjigaDAO();
            List<Knjiga> knjige = knjDao.Load();
            Knjiga k = null;
            for (int i = 0; i < knjige.Count; i++)
            {
                if (knjige[i].ISBN == kupovina.Knj.ISBN)
                {
                    k = knjige[i];
                    break;
                }
            }
            if (k == null)
                throw new ArgumentException("Ne postoji knjiga sa unetim ISBN.");
            k.Validate();
            kupovina.Validacija();
            List<Kupovina> kupovine = dao.Ucitaj();
            for (int i = 0; i < kupovine.Count; i++)
            {
                if (kupovine[i].Pos.CK == kupovina.Pos.CK && kupovine[i].Knj.ISBN==kupovina.Knj.ISBN && kupovine[i].DatKup==kupovina.DatKup)
                    throw new ArgumentException("Ova kupovina već postoji.");
            }
            if (kupovina.Pos != null)
            {
                if (kupovina.Pos.Kupljene == null)
                    kupovina.Pos.Kupljene = new List<Kupovina>();
                kupovina.Pos.Kupljene.Add(kupovina);
                kupovina.Pos.IzracunajProsek();
            }
            kupovine.Add(kupovina);
            dao.Sacuvaj(kupovine);
        }

        public void Izmeni(string ckIzmeni, string isbnIzmeni, DateTime datumIzmeni, Kupovina izmenjena)
        {
            List<Kupovina> kupovine = dao.Ucitaj();
            bool zamenjeno = false;
            for (int i = 0; i < kupovine.Count; i++)
            {
                if (kupovine[i].Pos.CK == ckIzmeni && kupovine[i].Knj.ISBN == isbnIzmeni && kupovine[i].DatKup == datumIzmeni)
                {
                    izmenjena.Validacija();
                    kupovine[i] = izmenjena;
                    zamenjeno = true;
                }
            }
            if (zamenjeno == false)
                throw new ArgumentException("Ne postoji ova kupovina");
            dao.Sacuvaj(kupovine);
            if (izmenjena.Pos != null)
            {
                if (izmenjena.Pos.Kupljene == null)
                    izmenjena.Pos.Kupljene = new List<Kupovina>();
                for (int i = 0; i < izmenjena.Pos.Kupljene.Count; i++)
                {
                    Kupovina k = izmenjena.Pos.Kupljene[i];
                    if (k.Pos.CK == ckIzmeni && k.Knj.ISBN == isbnIzmeni && k.DatKup == datumIzmeni)
                    {
                        izmenjena.Pos.Kupljene[i] = izmenjena;
                        break;
                    }
                }
                izmenjena.Pos.IzracunajProsek();
            }
        }

        public void Obrisi(string ckObrisi, string isbnObrisi, DateTime datumObrisi)
        {
            List<Kupovina> kupovine = dao.Ucitaj();
            bool obrisana = false;
            for (int i = 0; i < kupovine.Count; i++)
            {
                if (kupovine[i].Pos.CK == ckObrisi && kupovine[i].Knj.ISBN == isbnObrisi && kupovine[i].DatKup == datumObrisi)
                {
                    kupovine.RemoveAt(i);
                    obrisana = true;
                }
            }
            if (obrisana == false)
                throw new ArgumentException("Ne postoji ova kupovina");
            dao.Sacuvaj(kupovine);
            PosetilacDAO posDAO = new PosetilacDAO();
            List<Posetilac> posetioci = posDAO.Ucitaj();
            for (int i = 0; i < posetioci.Count; i++)
            {
                if (posetioci[i].CK == ckObrisi)
                {
                    if (posetioci[i].Kupljene != null)
                    {
                        for (int j = 0; j < posetioci[i].Kupljene.Count; j++)
                        {
                            Kupovina k = posetioci[i].Kupljene[j];
                            if (k.Knj.ISBN == isbnObrisi && k.DatKup == datumObrisi)
                            {
                                posetioci[i].Kupljene.RemoveAt(j);
                                break;
                            }
                        }
                        posetioci[i].IzracunajProsek();
                    }
                }
            }
        }

        public List<Kupovina> VratiSve()
        {
            return dao.Ucitaj();
        }

        public void Prikazi()
        {
            List<Kupovina> kupovine = dao.Ucitaj();
            if (kupovine.Count == 0)
            {
                Console.WriteLine("Nema kupovina");
                return;
            }
            for (int i = 0; i < kupovine.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + kupovine[i].ToString());
                Console.WriteLine("--------------------------------------");
            }
        }
    }
}

