﻿using System;
using System.Windows;
using Core.Models;
using Core.Services;

namespace WpfClient
{
    public partial class MainWindow : Window
    {
        private readonly KnjigaService _knjigaService = new KnjigaService();

        public MainWindow()
        {
            InitializeComponent();

            // 3/4 ekrana + centriranje (traženo)
            Width = SystemParameters.WorkArea.Width * 0.75;
            Height = SystemParameters.WorkArea.Height * 0.75;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;

            LoadData();
            SetStatus("Ready");
        }

        private void LoadData()
        {
            try
            {
                dgKnjige.ItemsSource = null;
                dgKnjige.ItemsSource = _knjigaService.GetAll();
                SetStatus("Učitane knjige");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju knjiga: " + ex.Message,
                    "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                SetStatus("Load error");
            }
        }

        private void BtnOsvezi_Click(object sender, RoutedEventArgs e) => LoadData();

        private void BtnDodaj_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // TEST dodatak (kasnije menjaš dijalogom)
                var nova = new Knjiga
                {
                    ISBN = "123-456",
                    Naziv = "Nova Knjiga",
                    Zanr = "Drama",
                    GodinaIzdanja = 2023,
                    Cena = 999,
                    BrojStrana = 250,
                    Izdavac = "Laguna"
                };

                _knjigaService.AddKnjiga(nova);
                LoadData();
                SetStatus("Knjiga dodata");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri dodavanju: " + ex.Message,
                    "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                SetStatus("Add error");
            }
        }

        private void BtnIzmeni_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dgKnjige.SelectedItem is not Knjiga selektovana)
                {
                    MessageBox.Show("Izaberi knjigu iz tabele.",
                        "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // Napravi novu knjigu sa izmenama (kasnije ćeš ovo popuniti iz dijaloga)
                var nova = new Knjiga
                {
                    ISBN = selektovana.ISBN, // ne menja se ključ
                    Naziv = selektovana.Naziv + " (izmena)",
                    Zanr = selektovana.Zanr,
                    GodinaIzdanja = selektovana.GodinaIzdanja,
                    Cena = selektovana.Cena,
                    BrojStrana = selektovana.BrojStrana,
                    Izdavac = selektovana.Izdavac
                };

                bool ok = _knjigaService.UpdateKnjiga(selektovana.ISBN, nova);

                if (!ok)
                {
                    MessageBox.Show("Knjiga nije pronađena (možda je obrisana).",
                        "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                LoadData();
                SetStatus("Knjiga izmenjena");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri izmeni: " + ex.Message,
                    "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                SetStatus("Update error");
            }
        }

        private void BtnObrisi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dgKnjige.SelectedItem is not Knjiga selektovana)
                {
                    MessageBox.Show("Izaberi knjigu iz tabele.",
                        "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                var res = MessageBox.Show(
                    $"Da li si sigurna da želiš da obrišeš knjigu:\n{selektovana.Naziv} ({selektovana.ISBN}) ?",
                    "Potvrda brisanja",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (res != MessageBoxResult.Yes) return;

                bool ok = _knjigaService.DeleteKnjiga(selektovana.ISBN);

                if (!ok)
                {
                    MessageBox.Show("Knjiga nije pronađena (možda je već obrisana).",
                        "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                LoadData();
                SetStatus("Knjiga obrisana");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri brisanju: " + ex.Message,
                    "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                SetStatus("Delete error");
            }
        }

        private void MenuExit_Click(object sender, RoutedEventArgs e) => Close();

        private void MenuAbout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("IS Sajam knjiga - WPF aplikacija", "About",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SetStatus(string text)
        {
            if (StatusText != null)
                StatusText.Text = text;
        }
    }
}
